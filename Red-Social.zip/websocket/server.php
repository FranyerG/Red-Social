<?php
require_once 'vendor/autoload.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

class Chat implements MessageComponentInterface {
    protected $clients;
    protected $users;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->users = [];
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "Nueva conexión ({$conn->resourceId})\n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        
        switch($data['type']) {
            case 'register':
                $this->users[$from->resourceId] = [
                    'conn' => $from,
                    'user_id' => $data['user_id'],
                    'username' => $data['username']
                ];
                break;
                
            case 'message':
                $messageData = [
                    'type' => 'message',
                    'from_user_id' => $this->users[$from->resourceId]['user_id'],
                    'from_username' => $this->users[$from->resourceId]['username'],
                    'message' => $data['message'],
                    'timestamp' => date('Y-m-d H:i:s')
                ];
                
                // Enviar mensaje a todos los clientes conectados
                foreach($this->clients as $client) {
                    $client->send(json_encode($messageData));
                }
                break;
                
            case 'private_message':
                $targetUserId = $data['to_user_id'];
                $messageData = [
                    'type' => 'private_message',
                    'from_user_id' => $this->users[$from->resourceId]['user_id'],
                    'from_username' => $this->users[$from->resourceId]['username'],
                    'message' => $data['message'],
                    'timestamp' => date('Y-m-d H:i:s')
                ];
                
                // Enviar mensaje privado al usuario específico
                foreach($this->users as $resourceId => $user) {
                    if($user['user_id'] == $targetUserId) {
                        $user['conn']->send(json_encode($messageData));
                        break;
                    }
                }
                break;
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        unset($this->users[$conn->resourceId]);
        echo "Conexión {$conn->resourceId} desconectada\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "Error: {$e->getMessage()}\n";
        $conn->close();
    }
}

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new Chat()
        )
    ),
    8080
);

echo "Servidor WebSocket ejecutándose en el puerto 8080...\n";
$server->run();
?>